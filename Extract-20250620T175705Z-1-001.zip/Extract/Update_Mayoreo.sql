


SELECT *
  FROM [Power_BI].[dbo].[Pto_Anual_Mayoreo]
  WHERE Dia >= '01/01/2024'


----UPDATE Presupuesto ---

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 10165256
WHERE Dia = '2024-01-31'


-----------------------------

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 10843669.72
WHERE Dia = '2024-02-29'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 14801803.81
WHERE Dia = '2024-03-31'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 12108176.51
WHERE Dia = '2024-04-30'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 16014021.16
WHERE Dia = '2024-05-31'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 16385383.76
WHERE Dia = '2024-06-30'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 15010332.2
WHERE Dia = '2024-07-31'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 15893702.88
WHERE Dia = '2024-08-31'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 17504239.96
WHERE Dia = '2024-09-30'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 16455006.81

WHERE Dia = '2024-10-31'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 26252278.42
WHERE Dia = '2024-11-30'

UPDATE Pto_Anual_Mayoreo
SET ValorPresupuesto = 21673129.87
WHERE Dia = '2024-12-31'

