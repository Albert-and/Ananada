SELECT *
  FROM [IV_Desarrollos].[dbo].[ProductoFaltante]