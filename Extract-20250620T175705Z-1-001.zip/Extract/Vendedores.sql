SELECT 
SlpCode,
SlpName,
Commission 
FROM  OSLP
