SELECT TOP (1000) [CategoríaTipo]
      ,[CategoríaNombre]
      ,[CategoríaID]
  FROM [Power_BI].[dbo].[CategoríaTipo]