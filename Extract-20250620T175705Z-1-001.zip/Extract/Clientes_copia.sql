

SELECT
CardCode AS 'CodigoCliente',
CardFName 'CodigoAnterior',
CardName 'Nombre',
GroupCode 'GrupoSN',
SlpCode,
Balance,
DNotesBal,
OrdersBal,
CreditLine,
DebtLine
FROM OCRD