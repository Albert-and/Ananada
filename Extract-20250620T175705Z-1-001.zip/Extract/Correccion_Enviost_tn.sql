


SELECT*
from [@IV_MAG_MKTDOC_CAB]
WHERE U_IdMagento = 1464789999



UPDATE [@IV_MAG_MKTDOC_CAB]
WHERE U_IdMagento = 1464395702

--Insert pra corregir erro en pedido----
UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_CodigoSN = 2067, U_Estatus = 0
wHERE Code = 20310
Where U_Email = 'ulises_tn@anandamx.online'
------------


UPDATE [@IV_MAG_MKTDOC_CAB]
SET  U_CostoEnvio = 260
WHERE U_IdMagento = 1465338639

UPDATE [@IV_MAG_MKTDOC_CAB]
SET  U_Fletera = 11
WHERE U_IdMagento = 1465338639

UPDATE [@IV_MAG_MKTDOC_CAB]
SET  U_Estatus = 0
WHERE U_IdMagento = 1465338639


SELECT*
from [@IV_MAG_MKTDOC_CAB]
WHERE U_IdMagento = 1465338639


-------------------------------------------


UPDATE [@IV_MAG_MKTDOC_CAB]
SET  U_Estatus = 0
WHERE U_IdMagento = 1464395702

UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_Fletera = 
WHERE U_IdMagento = 1464395702


UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_CodigoSN = 'CO200012'
WHERE U_IdMagento = 1464395702

--UPDATE [@IV_MAG_MKTDOC_CAB]
----SET  U_Moneda = 'MXP'


UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_CodigoSN = 'CO200012'

UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_FechaContabilizacion = '2024-04-16'

UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_FechaInsert = '2024-04-16'

UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_FechaReferencia = '2024-04-16'

UPDATE [@IV_MAG_MKTDOC_CAB]
SET U_FechaVencimiento = '2024-04-16'

2024-04-16

SELECT*
from OSHP

