

SELECT 
ItemCode,
ItemName,
FrgnName,
ItmsGrpCod,
CodeBars,
OnHand,
IsCommited,
OnOrder
FROM OITM