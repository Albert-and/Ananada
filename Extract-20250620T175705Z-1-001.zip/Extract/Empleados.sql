
select empID , lastName, firstName
from OHEM