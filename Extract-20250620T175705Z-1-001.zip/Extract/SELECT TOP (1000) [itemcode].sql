SELECT TOP (1000) [itemcode]
      ,[Categoria Mayoreo]
  FROM [Power_BI].[dbo].[cat_mayoreo]